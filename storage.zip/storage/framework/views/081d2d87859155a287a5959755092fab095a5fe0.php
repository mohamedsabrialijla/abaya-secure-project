<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH /home/abayasquare/public_html/resources/views/vendor/mail/html/table.blade.php ENDPATH**/ ?>