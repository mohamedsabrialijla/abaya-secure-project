[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/abayasquare/public_html/new/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>