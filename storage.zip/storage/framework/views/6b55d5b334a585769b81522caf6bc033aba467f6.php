<div class="input-group mr-2">
    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="text" name="<?php echo e($key); ?>" class="form-control m-input m-input--pill" style="border-radius: 0" value="<?php echo e(request()->$key); ?>"  placeholder="<?php echo e($text); ?>">

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <div class="input-group-append">
        <button class="<?php echo e(config('layout.classes.black')); ?>" type="submit"><i class="fa fa-search"></i></button>
    </div>
</div>
<?php /**PATH /home/abayasquare/public_html/new/resources/views/components/serach/inputwithsearch.blade.php ENDPATH**/ ?>