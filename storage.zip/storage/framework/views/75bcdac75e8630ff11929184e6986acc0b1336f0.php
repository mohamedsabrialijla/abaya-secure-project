<?php echo e($slot); ?>

<?php /**PATH /home/abayasquare/public_html/new/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>