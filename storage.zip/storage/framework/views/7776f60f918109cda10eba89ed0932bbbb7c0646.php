
<div id="kt_scrolltop" class="scrolltop">
	<?php echo e(Metronic::getSVG("media/svg/icons/Navigation/Up-2.svg")); ?>

	
</div>
<?php /**PATH /home/abayasquare/public_html/resources/views/layouts/partials/extras/_scrolltop.blade.php ENDPATH**/ ?>