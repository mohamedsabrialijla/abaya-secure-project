<h2>Hello Admin,</h2>
You received an email from : <?php echo e($name); ?>

Here are the details:
<br>
<b>Name:</b> <?php echo e($name); ?>

<br>
<b>Email:</b> <?php echo e($email); ?>

<br>
<b>Phone Number:</b> <?php echo e($phone_number); ?>

<br>
<b>Message:</b> <?php echo e($user_message); ?>

<br>
Thank You
<?php /**PATH /home/abayasquare/public_html/new/resources/views/web/contact_email.blade.php ENDPATH**/ ?>